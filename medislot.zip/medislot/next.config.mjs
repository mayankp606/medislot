/** @type {import('next').NextConfig} */
export default { serverExternalPackages: ["pdfkit"] };
